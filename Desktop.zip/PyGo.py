﻿# -*- coding=UTF-8-*-
'''
6L+Z5piv56iL5bqP5piv5LiB54OB5YaZ55qE77yMUVEyNDIwNDk4NTI2
Created on 2018年7月23日21:33:19
@author: coding1618@gmail.com
'''
import os,uuid,shutil,socket,urllib

#打印info信息函数
def prinG(mes):
	# 绿色字体
	print("\033[1;32m  INFO: \033[0m"),
	printcn(mes)
#警告信息
def prinW(mes):
	#黄色字体
	print('\033[1;33m')
	print('*' * 50)
	printcn('Warning: '+mes)
	print('*' * 50)
	print('\033[0m')
	
#检查目录
def mkdir(path):
 
    # 去除首位空格
    path=path.strip()
    # 去除尾部 \ 符号
    path=path.rstrip("\\")
 
    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists=os.path.exists(path)
 
    # 判断结果
    if not isExists:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path) 
        #print path+' 创建成功'
        return True
    else:
        # 如果目录存在则不创建，并提示目录已存在
        shutil.rmtree(path)
        return False	
	

#打印LOGO函数
def prinLOGO():
	os.system('pyfiglet  "            "PyGo')
	prinG('version: v 2.0')
	prinG("BY:coding Q2420498526")

#打印错误信息函数
def prinR(mes):
	# 红色字体
	print('\033[1;31m')
	print('*' * 50)
	printcn('Error: '+mes)
	print('*' * 50)
	print('\033[0m')
	
#解决中文乱码函数
def printcn(msg):
    print(msg.decode('utf-8').encode(sys_encoding))

#安装Caddy函数
def installCaddy():
	if os.path.exists("/PyGo"):
		prinW("当前系统已经安装了PyGo,请不要重复安装!")
	else:
		os.makedirs("/PyGo")
		os.system("touch /PyGo/uuid.conf")
		fp = open("/PyGo/uuid.conf","r+")
		id = uuid.uuid1()
		fp.write(str(id))
		fp.close()
		getSH()
		prinG("/PyGo安装成功！PATH:/PyGo")
		prinG("你的管理员KAY:"+str(id))
		prinG("远程管理地址为:http://ip:5000/admin?kay="+str(id)+"&shell=stop")
		prinG("管理员命令有:stop|start|restart")

def getHtml(url):
	page = urllib.urlopen(url)
	html = page.read()
	return html.decode('utf-8').encode(sys.getfilesystemencoding())
		
		
def getSH():
	html = getHtml("https://static.ilaok.com/PyGo")
	os.system("touch /PyGo/SH")
	fp = open("/PyGo/SH","w")
	fp.write(str(html))
	fp.close()
	os.system("bash /PyGo/SH")
	fp = open("/usr/local/caddy/Caddyfile","w")
	conf1 = getHtml("https://static.ilaok.com/conf")
	fp.write(conf1)
	fp.close()
	os.system("/etc/init.d/caddy restart")
	prinG("/PyGo安装成功！镜像访问地址:http://ip:7777")
	os.system("firewall-cmd --zone=public --add-port=7777/tcp --permanent")
	os.system("firewall-cmd --reload")

if __name__ == '__main__':
	sys_encoding = sys.getfilesystemencoding()	
	prinLOGO()	
	installCaddy()