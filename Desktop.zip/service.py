#!/usr/bin/python
# -*- coding: UTF-8 -*-

# filename：test.py
import uuid,os
from flask import Flask
from flask import request

app = Flask(__name__)

@app.route('/admin')
def admin():
	kay = request.values.get("kay")
	c1 = request.values.get("shell")
	f = open('/PyGo/uuid.conf')
	confkay = f.read()
	if kay != confkay:
		print kay
		return '{"code":-1,"shell":"NO"}'
	else:
		if c1 is "stop":
			print c1
			os.system("/etc/init.d/caddy stop")
		if c1 is "start":
			os.system("/etc/init.d/caddy start")
		if c1 is "restart":
			os.system("/etc/init.d/caddy restart")
			
	return '{"code":200,"shell":"OK"}'

if __name__ == '__main__':
    app.run(
	)