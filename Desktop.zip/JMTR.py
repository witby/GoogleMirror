# -*- coding=UTF-8-*-
'''
6L+Z5piv56iL5bqP5piv5LiB54OB5YaZ55qE77yMUVEyNDIwNDk4NTI2
Created on 2018年7月23日21:33:19
JDK TOMCAT MYSQL REDIS安装函数
@author: coding1618@gmail.com
'''
import os,sys,time,zipfile,shutil,pymysql.cursors

#打印info信息函数
def prinG(mes):
	# 绿色字体
	print("\033[1;32m  INFO: \033[0m"),
	printcn(mes)
#警告信息
def prinW(mes):
	#黄色字体
	print('\033[1;33m')
	print('*' * 50)
	printcn('Warning: '+mes)
	print('*' * 50)
	print('\033[0m')
#打印错误信息函数
def prinR(mes):
	# 红色字体
	print('\033[1;31m')
	print('*' * 50)
	printcn('Error: '+mes)
	print('*' * 50)
	print('\033[0m')

#解决中文乱码函数
def printcn(msg):
    print(msg.decode('utf-8').encode(sys_encoding))

	
	
#检查目录
def mkdir(path):
 
    # 去除首位空格
    path=path.strip()
    # 去除尾部 \ 符号
    path=path.rstrip("\\")
 
    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists=os.path.exists(path)
 
    # 判断结果
    if not isExists:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path) 
        #print path+' 创建成功'
        return True
    else:
        # 如果目录存在则不创建，并提示目录已存在
        shutil.rmtree(path)
        return False
	
	
#菜单函数
def menu():
	printcn('===========|请选择安装的功能序号|==============')
	prinG('	1.安装JDK1.7')
	prinG('	2.安装JDK1.8')
	prinG('	3.安装Tomcat7')
	prinG('	4.安装Tomcat8')
	prinG('	5.安装MySQL5.6')
	prinG('	6.安装Redis4.0')
	prinG('	version : 1.8 ')
	#prinG('	Email:coding1618@gmail.com : Q2420498526 ')
	#prinG('	7.设置MySQL密码')
	printcn('==========|请不要重复安装后果自负！|============')

#jdk7安装函数
def JDK7():
	prinW('正在执行安装JDK7,请稍后....')
	os.system("wget https://code-1251969687.cos.ap-chengdu.myqcloud.com/java/jdk1.7.rpm")
	JDK7 = os.system('rpm -ivh ./jdk1.7.rpm');
	if JDK7 != 0:
		prinR('JDK7安装失败！具体原因:看上面提示！')
	else:
		print JDK7
		prinG('JDK1.7安装完成请输入java -version查看版本')
	os.remove("./jdk1.7.rpm")
#jdk8安装函数
def JDK8():		
	prinW('正在执行安装JDK8,请稍后....')
	os.system("wget https://code-1251969687.cos.ap-chengdu.myqcloud.com/java/jdk8.rpm")
	JDK8 = os.system('rpm -ivh ./jdk8.rpm');
	if JDK8 != 0:
		prinR('JDK8安装失败！具体原因:看上面提示！')
	else:
		print JDK8
		prinG('JDK8安装完成请输入java -version查看版本')
	os.remove("./jdk8.rpm")
	
#TOMCAT7安装函数
def Tomcat7():
	prinW('正在执行安装Tomcat7,请稍后....')
	if os.path.exists("/www/Tomcat7"):
		prinW("当前系统已经安装了Tomact7,请不要重复安装!")
	else:
		os.makedirs("/www/Tomcat7")
		#解压资源函数
		os.system("wget https://code-1251969687.cos.ap-chengdu.myqcloud.com/java/Tomcat7.zip")
		f = zipfile.ZipFile("./Tomcat7.zip",'r')
		for file in f.namelist():
			f.extract(file,'/www/Tomcat7')
		if f != None:
			f.close()
		os.remove("./Tomcat7.zip")
		set_firewalld()
		os.system("cd /www/Tomcat7/apache-tomcat-7.0.90/bin/ && chmod +x *.sh")
		prinG("Tomcat7安装成功！PATH:/www/Tomcat7/apache-tomcat-7.0.90/")

#TOMCAT8安装函数
def Tomcat8():
	prinW('正在执行安装Tomcat8,请稍后....')
	if os.path.exists("/www/Tomcat8"):
		prinW("当前系统已经安装了Tomact8,请不要重复安装!")
	else:
		os.makedirs("/www/Tomcat8")
		#解压资源函数
		os.system("wget https://code-1251969687.cos.ap-chengdu.myqcloud.com/java/Tomcat8.zip")
		f = zipfile.ZipFile("./Tomcat8.zip",'r')
		for file in f.namelist():
			f.extract(file,'/www/Tomcat8')
		if f != None:
			f.close()
		os.remove("./Tomcat8.zip")
		set_firewalld()
		os.system("cd /www/Tomcat8/apache-tomcat-8.0.53/bin/ && chmod +x *.sh")
		prinG("Tomcat8安装成功！PATH:/www/Tomcat8/apache-tomcat-8.0.53/")	
	

	
#MySQL安装函数
def mysql5():
	prinW('正在执行安装MySQL5.6,请稍后....')
	MySQL5 = os.system('rpm -Uvh http://dev.mysql.com/get/mysql-community-release-el7-5.noarch.rpm');
	if MySQL5 != 0:
		prinR('MySQL5.6安装失败！具体原因:看上面提示！')
	else:
		print MySQL5
		os.system('yum install -y mysql-community-server')
		os.system('sudo service mysqld start')
		os.system('sudo service mysqld status')
		os.system('systemctl enable mysqld')
		#os.system('/usr/bin/systemctl enable mysqld')
		setPWD()
		set_firewalld()
			
#设置MySQL密码
def setPWD():
	# 连接MySQL数据库
	connection = pymysql.connect(host='127.0.0.1', port=3306, user='root', password='', db='mysql',charset='utf8mb4', cursorclass=pymysql.cursors.DictCursor)
	# 通过cursor创建游标
	cursor = connection.cursor()
	prinG('MySQL5.6安装完成！请在下面设置MySQL的密码:')
	password = raw_input("请输入新密:");
	# 创建sql 语句，并执行
	sql = 'update user set password=password('+str(password)+') where user="root";'
	cursor.execute(sql)
	#为root添加远程连接的能力  
	sql2 = 'GRANT ALL PRIVILEGES ON *.* TO root@"%" IDENTIFIED BY "'+str(password)+'";'
	cursor.execute(sql2)
	#删除匿名用户
	sql3 = 'delete from mysql.user where user="";';
	cursor.execute(sql3)
	#刷新权限
	sql4 = "flush privileges;"
	cursor.execute(sql4)
	# 提交SQL
	connection.commit()
	# 关闭数据连接
	connection.close()	
	#重启MySQL服务
	os.system("service mysqld restart")
	# if pwd is 0:
		# data = os.system('show database;')
		# print data
	prinG("MySQL密码设置成功,密码为:"+password)
	# else:
		# prinR("密码设置错误")
		
			
#Redis安装函数
def Redis():
	prinW('正在执行安装Redis4.0,请稍后....')
	os.system("yum install -y gcc tcl")
	redis = os.system("wget http://download.redis.io/releases/redis-4.0.10.tar.gz")
	if redis != 0:
		prinR('Redis安装失败！具体原因:看上面提示！')
	else:
		print redis
		if os.path.exists("/www/Redis"):
			prinW("当前系统已经安装了Redis,请不要重复安装!")
		else:
			setRedisConf()
			set_firewalld()
#设置redis配置
def setRedisConf():
	os.makedirs("/www/Redis")
	#编译安装
	os.system("tar -zxvf redis-4.0.10.tar.gz -C /www/Redis/")
	os.system("cd /www/Redis/redis-4.0.10 && make MALLOC=libc")
	os.system("cd /www/Redis/redis-4.0.10/src && make install")
	os.system("cd /www/Redis/redis-4.0.10/src/ && wget https://code-1251969687.cos.ap-chengdu.myqcloud.com/java/my_redis.conf")
	os.system("cd /www/Redis/redis-4.0.10/src/ && ./redis-server ./my_redis.conf")
	#os.system("nohup ./redis-server >Redis.out 2>&1 &")
	prinG("Redis安装成功！PATH:/www/Redis/redis-4.0.10")	
	prinG('Redis端口:6379')
	#prinG('Redis后台日志信息保存在:/www/Redis/redis-4.0.10/src/Redis.out')

#设置防火墙
def add_PORT(port):
	os.system("firewall-cmd --zone=public --add-port="+str(port)+"/tcp --permanent")

def set_firewalld():
	add_PORT('80')
	add_PORT('22')
	add_PORT('443')
	add_PORT('3306')
	add_PORT('6379')
	add_PORT('8080')
	os.system("firewall-cmd --reload")

if __name__ == '__main__':
	#获取系统编码
	syscode = '6L+Z5piv56iL5bqP5piv5LiB54OB5YaZ55qE77yMUVEyNDIwNDk4NTI2'
	sys_encoding = sys.getfilesystemencoding()
	#获取命令行参数
	try:
		c1 = sys.argv[1]
	except:
		menu()
	else:
		menu()
		if c1 is "1":
			JDK7()
		if c1 is "2":
			JDK8()
		if c1 is "3":
			Tomcat7()
		if c1 is "4":
			Tomcat8()
		if c1 is "5":
			mysql5()
		if c1 is "6":
			Redis()